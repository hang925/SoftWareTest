package nl.tudelft.jpacman.level;

import nl.tudelft.jpacman.PacmanConfigurationException;
import nl.tudelft.jpacman.board.BoardFactory;
import nl.tudelft.jpacman.board.Square;
import nl.tudelft.jpacman.npc.Ghost;
import org.junit.jupiter.api.*;

import java.io.IOException;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class MapParserTest {
    private MapParser mapParser;
    private final LevelFactory levelCreator = mock(LevelFactory.class);
    private final BoardFactory boardFactory = mock(BoardFactory.class);


    @BeforeEach
    void setUp() {
        mapParser = new MapParser(levelCreator,boardFactory);

        when(levelCreator.createGhost()).thenReturn(mock(Ghost.class));
        when(levelCreator.createPellet()).thenReturn(mock(Pellet.class));

        when(boardFactory.createGround()).thenReturn(mock(Square.class));
        when(boardFactory.createWall()).thenReturn(mock(Square.class));
    }

    @Test
    @Order(1)
    @DisplayName("文件名为空")
    void testNullFile() {
        assertThatThrownBy(()->{
            mapParser.parseMap((String) null);
            }).isInstanceOf(NullPointerException.class);
    }

    @Test
    @Order(2)
    @DisplayName("文件不存在")
    void testNotExistFile() {
        String notexistfile = "/notexist.txt";
        assertThatThrownBy(()->{
            mapParser.parseMap(notexistfile);
        }).isInstanceOf(PacmanConfigurationException.class)
            .hasMessage("Could not get resource for: " + notexistfile);
    }

    @Test
    @Order(3)
    @DisplayName("可识别的地图")
    void testExistFile() throws IOException {
        String path = "/simplemap.txt";
        mapParser.parseMap(path);

        verify(boardFactory,times(4)).createGround();
        verify(boardFactory,times(2)).createWall();
        verify(levelCreator,times(1)).createGhost();
        verify(levelCreator,times(1)).createPellet();
    }

    @Test
    @Order(4)
    @DisplayName("不可识别的地图")
    void testUnrecognizedMap() {
        String path = "/unrecognizedcharmap.txt";
        assertThatThrownBy(()->{
            mapParser.parseMap(path);
        }).isInstanceOf(PacmanConfigurationException.class);
    }

    @Test
    @Order(5)
    @DisplayName("只有玩家没有魔鬼的地图")
    void testNoGhostMap() throws IOException{
        String path = "/simplemapOfPlayer.txt";
        mapParser.parseMap(path);

        verify(boardFactory,times(3)).createGround();
        verify(boardFactory,times(3)).createWall();
        verify(levelCreator,times(1)).createPellet();
    }

}
