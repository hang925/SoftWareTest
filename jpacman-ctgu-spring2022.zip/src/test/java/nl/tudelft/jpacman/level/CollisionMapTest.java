package nl.tudelft.jpacman.level;

import nl.tudelft.jpacman.npc.Ghost;
import nl.tudelft.jpacman.points.PointCalculator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class CollisionMapTest {
    //初始化 生成set方法
    private PointCalculator pointCalculator;
    private Player player;
    private Ghost ghost;
    private Pellet pellet;
    private CollisionMap collisionMap;

    public void setPointCalculator(PointCalculator pointCalculator) {
        this.pointCalculator = pointCalculator;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public void setGhost(Ghost ghost) {
        this.ghost = ghost;
    }

    public void setPellet(Pellet pellet) {
        this.pellet = pellet;
    }

    public void setCollisionMap(CollisionMap collisionMap) {
        this.collisionMap = collisionMap;
    }

    public PointCalculator getPointCalculator() {
        return pointCalculator;
    }

    @BeforeEach
    void setUp() {
        setPointCalculator(Mockito.mock(PointCalculator.class));
        setPlayer(Mockito.mock(Player.class));
        setGhost(Mockito.mock(Ghost.class));
        setPellet(Mockito.mock(Pellet.class));
        setCollisionMap(new PlayerCollisions(this.getPointCalculator()));
    }



    //玩家&&玩家碰撞判断
    @Test
    @DisplayName("玩家,玩家发生碰撞")
    void testPlayerPlayer() {
        Player player1 = Mockito.mock(Player.class);
        collisionMap.collide(player, player1);

        Mockito.verifyZeroInteractions(player, player1);//确保所有内容均通过验证
    }

    //玩家&&魔碰撞
    @Test
    @DisplayName("玩家,魔鬼发生碰撞")
    void testPlayerGhost() {
        collisionMap.collide(player, ghost);

        Mockito.verify(pointCalculator, Mockito.times(1)).collidedWithAGhost(
            Mockito.eq(player),
            Mockito.eq(ghost)
        );

        Mockito.verify(player, Mockito.times(1)).setAlive(false); //碰撞后玩家被杀死
        Mockito.verify(player, Mockito.times(1)).setKiller(Mockito.eq(ghost));
        Mockito.verifyNoMoreInteractions(player, ghost);//确保所有内容均通过验证
    }

    //魔鬼&&玩家碰撞
    @Test
    @DisplayName("魔鬼、玩家发生碰撞")
    void testGhostPlayer() {
        collisionMap.collide(ghost, player);

        Mockito.verify(pointCalculator, Mockito.times(1)).collidedWithAGhost(
            Mockito.eq(player),
            Mockito.eq(ghost)
        );

        Mockito.verify(player, Mockito.times(1)).setAlive(false); //碰撞后玩家被杀死
        Mockito.verify(player, Mockito.times(1)).setKiller(Mockito.eq(ghost));
        Mockito.verifyNoMoreInteractions(player, ghost);//确保所有内容均通过验证
    }


    //玩家&&豆子碰撞（玩家吃豆子）
    @Test
    @DisplayName("玩家,豆子发生碰撞")
    void testPlayerPellet() {
        collisionMap.collide(player, pellet);
        Mockito.verify(pointCalculator, Mockito.times(1)).consumedAPellet( //吃到豆子后，递增分数
            Mockito.eq(player),
            Mockito.eq(pellet)
        );

        Mockito.verify(pellet, Mockito.times(1)).leaveSquare(); //被吃到后，移除豆子
        Mockito.verifyNoMoreInteractions(player, pellet); //确保所有内容均通过验证
    }

    //豆子&&玩家碰撞（玩家吃豆子）
    @Test
    @DisplayName("豆子,玩家发生碰撞")
    void testPelletPlayer() {
        collisionMap.collide(pellet, player);
        Mockito.verify(pointCalculator, Mockito.times(1)).consumedAPellet( //吃到豆子后，递增分数
            Mockito.eq(player),
            Mockito.eq(pellet)
        );

        Mockito.verify(pellet, Mockito.times(1)).leaveSquare(); //被吃到后，移除豆子
        Mockito.verifyNoMoreInteractions(player, pellet); //确保所有内容均通过验证
    }


    //魔鬼&&豆子发生碰撞
    @Test
    @DisplayName("魔鬼,豆子发生碰撞")
    void testGhostPellet() {
        collisionMap.collide(ghost, pellet);

        Mockito.verifyZeroInteractions(ghost, pellet);//确保所有内容均通过验证
    }

    //豆子&&魔鬼发生碰撞
    @Test
    @DisplayName("豆子,魔鬼发生碰撞")
    void testPelletGhost() {
        collisionMap.collide(pellet, ghost);

        Mockito.verifyZeroInteractions(ghost, pellet);//确保所有内容均通过验证
    }

    //魔鬼&&魔鬼发生碰撞
    @Test
    @DisplayName("魔鬼和魔鬼发生碰撞")
    void testGhostGhost() {
        Ghost ghost1 = Mockito.mock(Ghost.class);
        collisionMap.collide(ghost, ghost1);

        Mockito.verifyZeroInteractions(ghost, ghost1);
    }

    //豆子&&豆子碰撞
    @Test
    @DisplayName("豆子和豆子发生碰撞")
    void testPelletPellet() {
        Pellet pellet1 = Mockito.mock(Pellet.class);
        collisionMap.collide(pellet, pellet1);

        Mockito.verifyZeroInteractions(pellet, pellet1);
    }

}
