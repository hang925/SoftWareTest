package nl.tudelft.jpacman.npc.ghost;

import nl.tudelft.jpacman.board.BoardFactory;
import nl.tudelft.jpacman.board.Direction;
import nl.tudelft.jpacman.level.Level;
import nl.tudelft.jpacman.level.LevelFactory;
import nl.tudelft.jpacman.level.Player;
import nl.tudelft.jpacman.level.PlayerFactory;
import nl.tudelft.jpacman.points.DefaultPointCalculator;
import nl.tudelft.jpacman.points.PointCalculator;
import nl.tudelft.jpacman.sprite.PacManSprites;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.io.PrintWriter;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.assertj.core.api.AssertionsForClassTypes.in;
import static org.junit.jupiter.api.Assertions.*;

/**
 *@author hang
 *@version jdk1.8.0
 */
public class InkyTest {
        private PacManSprites pacManSprites;
        private LevelFactory levelFactory;
        private GhostFactory ghostFactory;
        private PlayerFactory playerFactory;
        private BoardFactory boardFactory;
        private GhostMapParser ghostMapParser;
        private PointCalculator pointCalculator;
        /*
         *初始化
         *@return 没有返回值
         */
        @BeforeEach
        void Init(){
            pacManSprites=new PacManSprites();
            boardFactory=new BoardFactory(pacManSprites);
            ghostFactory=new GhostFactory(pacManSprites);
            pointCalculator=new DefaultPointCalculator();
            levelFactory=new LevelFactory(pacManSprites,ghostFactory,pointCalculator);
            playerFactory=new PlayerFactory(pacManSprites);
            ghostMapParser=new GhostMapParser(levelFactory,boardFactory,ghostFactory);
        }
        /*
         *第一种情况，没有BilnkyGhost
         *@return 没有返回值
         */
        @Test
        void testNoBlinkyGhost(){
            Level level = ghostMapParser.parseMap(
                Lists.newArrayList("###PI ", "######")
            );
            Player player = playerFactory.createPacMan();
            player.setDirection(Direction.WEST);              //设定初始方向
            level.registerPlayer(player);

            Inky inky = Navigation.findUnitInBoard(Inky.class, level.getBoard());

            assertThat(inky.nextAiMove()).isEqualTo(Optional.empty());

        }
        /*
         *第二种情况，没有通路
         *@return 没有返回值
         */
        @Test
        void testNoPath(){ //第二种情况 没有通路
            Level level=ghostMapParser.parseMap(
                Lists.newArrayList(
                    "############", "  #P#  I  B#", "############"
                )
            );
            Player player=playerFactory.createPacMan();
            player.setDirection(Direction.WEST);
            level.registerPlayer(player);

            Inky inky=Navigation.findUnitInBoard(Inky.class,level.getBoard());

            assertThat(inky.nextAiMove()).isEqualTo(Optional.empty());
        }
        /*
         *第二种情况，没有玩家
         *@return 没有返回值
         */
        @Test
        void testNoPlayer(){
            Level level=ghostMapParser.parseMap(
                Lists.newArrayList(
                    "####", "B  I", "####"
                )
            );
            Inky inky=Navigation.findUnitInBoard(Inky.class,level.getBoard());
            assertThat(inky.nextAiMove()).isEqualTo(Optional.empty());
        }
        /*
         *第四种情况，向玩家移动
         *@return 没有返回值
         */
        @Test
        void testGoTowardPlayer(){
            Level level=ghostMapParser.parseMap(
                Lists.newArrayList(
                    "#################","#    P    B   I #","#################"
                )
            );
            Player player=playerFactory.createPacMan();
            player.setDirection(Direction.EAST);
            level.registerPlayer(player);
            Inky inky=Navigation.findUnitInBoard(Inky.class,level.getBoard());
            assertThat(inky.nextAiMove()).isEqualTo(Optional.of(Direction.WEST));
        }

        @Test
        void testInkyMoveAway(){
            Level level=ghostMapParser.parseMap(
                Lists.newArrayList(
                    "##############","#  B P  I    #","##############"

                )
            );
            Player player = playerFactory.createPacMan();
            player.setDirection(Direction.EAST);
            level.registerPlayer(player);
            Inky inky = Navigation.findUnitInBoard(Inky.class, level.getBoard());

            assertThat(inky.nextAiMove()).isEqualTo(Optional.of(Direction.EAST));
        }

    @Test
    void testInkyMove(){
        Level level = ghostMapParser.parseMap(
            Lists.newArrayList(
                "#########","# P  I B#","#########"
            )
        );
        Player player = playerFactory.createPacMan();
        player.setDirection(Direction.WEST);
        level.registerPlayer(player);
        Inky inky = Navigation.findUnitInBoard(Inky.class,level.getBoard());

        assertThat(inky.nextAiMove()).isEqualTo(Optional.ofNullable(Direction.WEST));
    }
}
